﻿using System;

namespace MMR.Randomizer.Attributes
{
    public class ProgressiveAttribute : Attribute
    {
    }
}
