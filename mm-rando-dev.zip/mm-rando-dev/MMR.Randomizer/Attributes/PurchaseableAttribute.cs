﻿using System;

namespace MMR.Randomizer.Attributes
{
    public class PurchaseableAttribute : Attribute
    {
    }
}
