﻿using System;

namespace MMR.Randomizer.Attributes
{
    public class OverwritableAttribute : Attribute
    {
    }
}
