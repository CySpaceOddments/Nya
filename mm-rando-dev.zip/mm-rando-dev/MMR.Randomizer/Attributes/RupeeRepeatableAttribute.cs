﻿using System;

namespace MMR.Randomizer.Attributes
{
    public class RupeeRepeatableAttribute : Attribute
    {
    }
}
