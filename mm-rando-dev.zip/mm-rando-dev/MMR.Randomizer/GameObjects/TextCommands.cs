﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMR.Randomizer.GameObjects
{
    public class TextCommands
    {
        public const char ColorWhite = '\x00';
        public const char ColorRed = '\x01';
        public const char ColorGreen = '\x02';
        public const char ColorDarkBlue = '\x03';
        public const char ColorYellow = '\x04';
        public const char ColorLightBlue = '\x05';
        public const char ColorPink = '\x06';
        public const char ColorSilver = '\x07';
        public const char ColorOrange = '\x08';
    }
}
