﻿namespace MMR.Randomizer.Patch
{
    public enum PatchCommand : ushort
    {
        ExistingFile,
        NewFile,
    }
}
