﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMR.Randomizer.Models.Vectors
{
    public class vecf32
    {
        public float x = new float();
        public float y = new float();
        public float z = new float();
    }

}
