﻿using MMR.Randomizer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMR.Randomizer.Templates
{
    partial class HtmlSpoiler
    {
        private Spoiler spoiler;

        public HtmlSpoiler(Spoiler spoiler)
        {
            this.spoiler = spoiler;
        }
    }
}
