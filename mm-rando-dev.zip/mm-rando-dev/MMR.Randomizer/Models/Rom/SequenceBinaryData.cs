﻿
namespace MMR.Randomizer.Models.Rom
{

    public class SequenceBinaryData
    {
        public byte[] SequenceBinary { get; set; } = null; // binary copy of the zsequence
        public InstrumentSetInfo InstrumentSet { get; set; } = null;
        public byte[] FormMask { get; internal set; }
    }
}

