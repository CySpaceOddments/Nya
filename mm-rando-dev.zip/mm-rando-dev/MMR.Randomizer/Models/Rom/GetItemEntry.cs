﻿namespace MMR.Randomizer.Models.Rom
{
    public class GetItemEntry
    {
        public byte ItemGained;
        public byte Flag;
        public byte Index;
        public byte Type;
        public short Message;
        public short Object;
    }
}
