﻿namespace MMR.Randomizer.Models.Rom
{
    /// <summary>
    /// Named file indexes.
    /// </summary>
    /// <remarks>TODO: Fill this out later.</remarks>
    public enum FileIndex : int
    {
        code = 31,
    }
}
