﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMR.Randomizer.Models.Rom
{
    public class BottleCatchEntry
    {
        public short Identifier;
        public byte Type;
        public byte ItemGained;
        public byte Index;
        public byte Message;
    }
}
