﻿namespace MMR.Randomizer.Models.Settings
{
    public enum ColorSelectionMode
    {
        Customized,
        RandomChoice,
        CompletelyRandom,
    }
}
