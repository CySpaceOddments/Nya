﻿namespace MMR.Randomizer.Models
{
    public enum MovementMode
    {
        Default,
        HighSpeed,
        SuperLowGravity,
        LowGravity,
        HighGravity
    }
}
