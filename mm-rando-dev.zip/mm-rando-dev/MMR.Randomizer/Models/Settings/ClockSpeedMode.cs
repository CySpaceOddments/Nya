﻿namespace MMR.Randomizer.Models.Settings
{
    public enum ClockSpeed
    {
        Default,
        VerySlow,
        Slow,
        Fast,
        VeryFast,
        SuperFast
    }
}
