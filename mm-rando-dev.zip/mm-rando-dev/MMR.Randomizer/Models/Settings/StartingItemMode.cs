﻿namespace MMR.Randomizer.Models
{
    public enum StartingItemMode
    {
        None,
        Random,
        AllowTemporaryItems,
    }
}
