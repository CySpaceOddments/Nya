﻿namespace MMR.Randomizer.Models.Settings
{
    public enum BlastMaskCooldown
    {
        Default,
        Instant,
        VeryShort,
        Short,
        Long,
        VeryLong
    }
}
