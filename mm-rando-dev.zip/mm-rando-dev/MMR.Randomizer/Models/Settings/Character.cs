﻿namespace MMR.Randomizer.Models
{
    public enum Character
    {
        LinkMM,
        LinkOOT,
        AdultLink,
        Kafei
    }
}
