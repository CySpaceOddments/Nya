﻿namespace MMR.Randomizer.Models
{
    public enum TatlColorSchema
    {
        Default,
        Dark,
        Hot,
        Cool,
        Random,
        Rainbow,
    }
}
