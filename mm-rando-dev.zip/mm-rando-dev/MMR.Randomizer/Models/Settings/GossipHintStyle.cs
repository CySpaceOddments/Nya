﻿namespace MMR.Randomizer.Models
{
    public enum GossipHintStyle
    {
        Default,
        Random,
        Relevant,
        Competitive,
    }
}
