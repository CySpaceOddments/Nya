﻿namespace MMR.Randomizer.Models
{
    public enum DamageEffect
    {
        Default,
        Fire,
        Ice,
        Shock,
        Knockdown,
        Random
    }
}
