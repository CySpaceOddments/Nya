﻿namespace MMR.Randomizer.Models.Settings
{
    public enum NutAndStickDrops
    {
        Default = 0,
        Light   = 1,
        Medium  = 2,
        Extra   = 3,
        Mayhem  = 4
    }
}
