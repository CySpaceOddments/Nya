﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MMR.Randomizer.Models.Settings
{
    public enum CombatMusic
    {
        Normal,
        WeakEnemies,
        All
    }
}
