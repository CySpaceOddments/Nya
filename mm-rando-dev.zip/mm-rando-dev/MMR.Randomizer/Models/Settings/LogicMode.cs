﻿namespace MMR.Randomizer.Models
{
    public enum LogicMode
    {
        Casual,
        Glitched,
        Vanilla,
        UserLogic,
        NoLogic,
    }
}
