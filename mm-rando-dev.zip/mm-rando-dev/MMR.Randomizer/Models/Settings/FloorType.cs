﻿namespace MMR.Randomizer.Models
{
    public enum FloorType
    {
        Default,
        Sand,
        Ice,
        Snow,
        Random
    }
}
