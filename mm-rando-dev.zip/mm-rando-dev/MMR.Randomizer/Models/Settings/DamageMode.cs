﻿using MMR.Randomizer.Attributes;

namespace MMR.Randomizer.Models
{
    public enum DamageMode
    {
        Default,
        Double,
        Quadruple,
        OHKO,
        Doom
    }
}
