﻿namespace MMR.Randomizer.Models
{
    public enum Music
    {
        Default,
        Random,
        None,
    }
}
