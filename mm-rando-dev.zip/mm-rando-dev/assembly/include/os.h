#ifndef _OS_H_
#define _OS_H_

#include <PR/ultratypes.h>

typedef u64 OSTime;

#endif
