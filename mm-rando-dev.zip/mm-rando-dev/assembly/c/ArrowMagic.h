#ifndef ARROW_MAGIC_H
#define ARROW_MAGIC_H

#include <z64.h>

void ArrowMagic_Handle(ActorPlayer* player, GlobalContext* ctxt);

#endif // ARROW_MAGIC_H
