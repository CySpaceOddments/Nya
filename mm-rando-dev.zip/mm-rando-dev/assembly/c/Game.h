#ifndef GAME_H
#define GAME_H

#include <stdbool.h>

bool Game_IsKaleidoScope(void);
bool Game_IsPlayerActor(void);

#endif // GAME_H
