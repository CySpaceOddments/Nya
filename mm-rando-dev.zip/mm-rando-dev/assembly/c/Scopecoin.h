#ifndef SCOPECOIN_H
#define SCOPECOIN_H

#include <z64.h>

u16 Scopecoin_GetGiIndex(Actor* actor);

#endif // SCOPECOIN_H
