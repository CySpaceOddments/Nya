#ifndef EXTENDED_OBJECTS_H
#define EXTENDED_OBJECTS_H

#include <z64.h>

#define EXT_OBJECT_COUNT 32

ObjectFileTableEntry* ExtendedObjects_Get(s16 index);

#endif // EXTENDED_OBJECTS_H
