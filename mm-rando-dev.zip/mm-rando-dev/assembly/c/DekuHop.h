#ifndef DEKU_HOP_H
#define DEKU_HOP_H

#include <z64.h>

void DekuHop_Handle(ActorPlayer* player, GlobalContext* ctxt);

#endif // DEKU_HOP_H
