#ifndef OVERLAY_MENU_H
#define OVERLAY_MENU_H

#include <z64.h>

void OverlayMenu_Draw(GlobalContext* ctxt);

#endif // OVERLAY_MENU_H
