#include <z64.h>
#include "Models.h"

void Room_AfterLoad(GlobalContext* ctxt, RoomContext* roomCtxt, u32 roomIdx) {
}

void Room_AfterUnload(GlobalContext* ctxt, RoomContext* roomCtxt) {
}

void Room_beforeLoad(GlobalContext* ctxt, RoomContext* roomCtxt, u32 roomIdx) {
}

void Room_BeforeUnload(GlobalContext* ctxt, RoomContext* roomCtxt) {
}
