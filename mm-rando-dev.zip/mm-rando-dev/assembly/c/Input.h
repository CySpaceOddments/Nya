#ifndef INPUT_H
#define INPUT_H

#include <z64.h>

extern Input gPlayUpdateInput;

#endif // INPUT_H
