#ifndef ITEM_OVERRIDE_H
#define ITEM_OVERRIDE_H

#include <stdbool.h>
#include <z64.h>

bool ItemOverride_GetGraphic(u32 index, u16* graphic, u16* object);

#endif // ITEM_OVERRIDE_H
