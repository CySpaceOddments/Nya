#ifndef TARGET_HEALTH_H
#define TARGET_HEALTH_H

#include <z64.h>

void TargetHealth_AfterActorInit(Actor* actor, GlobalContext* ctxt);

#endif // TARGET_HEALTH_H
