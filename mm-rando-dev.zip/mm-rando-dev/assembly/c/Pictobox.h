#ifndef PICTOBOX_H
#define PICTOBOX_H

const char* Pictobox_CurrentText(void);

#endif // PICTOBOX_H
