#ifndef ITEM00_H
#define ITEM00_H

#include <z64.h>

void Item00_LoadCollectableTable(GlobalContext* ctxt);

#endif // ITEM00_H
